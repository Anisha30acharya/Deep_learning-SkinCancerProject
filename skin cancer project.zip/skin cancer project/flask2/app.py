from flask import Flask, render_template, request
import os
import numpy as np
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
from werkzeug.utils import secure_filename

app = Flask(__name__)

# Configuration
MODEL_PATH = 'skin_cancer_model.h5'
UPLOAD_FOLDER = os.path.join('static', 'uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Load trained model
model = load_model(MODEL_PATH)

# Class names (must match training order)
class_names = [
    'Actinic keratoses and intraepithelial carcinoma',
    'Basal cell carcinoma',
    'Benign keratosis',
    'Dermatofibroma',
    'Melanoma',
    'Melanocytic nevi',
    'Vascular lesions'
]


# File type check
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


# Home route
@app.route('/')
def home():
    return render_template('DNNHome.html')


# Predict route
@app.route('/predict', methods=['GET', 'POST'])
def predict():
    if request.method == 'POST':
        if 'file' not in request.files:
            return render_template('DNNresult.html', error="No file uploaded.")

        file = request.files['file']
        if file.filename == '':
            return render_template('DNNresult.html', error="No file selected.")

        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)

            # Preprocess the image
            img = image.load_img(filepath, target_size=(224, 224))
            img_array = image.img_to_array(img)
            img_array = np.expand_dims(img_array, axis=0) / 255.0

            # Make prediction
            prediction = model.predict(img_array)
            pred_index = np.argmax(prediction)
            predicted_class = class_names[pred_index] if pred_index < len(class_names) else "Unknown"

            return render_template('DNNresult.html',
                                   prediction=predicted_class,
                                   image_file='uploads/' + filename)

        else:
            return render_template('DNNresult.html', error="Invalid file format.")
    else:
        return render_template('DNNresult.html')


if __name__ == '__main__':
    app.run(debug=True)
